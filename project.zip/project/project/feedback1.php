<html>
        <head>
                <title>FeedBack</title>
</head>
<body>
        <?php
        $name = $_POST['name'];
        $emailid=$_POST['emailid'];
        $feedback = $_POST['feedback'];
            
	$conn = mysqli_connect("localhost","project","project");
        $db = mysqli_select_db($conn,"project"); 
        function function_alert($message) { 
      
            // Display the alert box  
            echo "<script>alert('$message');";
            echo 'window.location.href = "Home.html";';
            echo"</script>"; 
        } 
                    $query2=   "INSERT INTO feedback VALUES ('$name','$emailid','$feedback')" ; 
                    $result2 = mysqli_query($conn,$query2) or die("Query failed: ".mysqli_error($conn));
                    function_alert("Thank you For your Feedback");
                    //header('Location: hii.html');
 
?>
</body>
        </html>